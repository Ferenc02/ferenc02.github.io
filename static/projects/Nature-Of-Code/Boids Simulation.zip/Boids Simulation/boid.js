let scalar = 1;

class Boid {
	constructor() {
		this.offsetBorder = 0;
		this.boidSize = 10;

		this.position = createVector(
			Math.floor(Math.random() * width),
			Math.floor(Math.random() * height)
		);

		this.velocity = createVector(0, 0);

		this.vector1 = createVector(0, 0);
		this.vector2 = createVector(0, 0);
		this.vector3 = createVector(0, 0);
	}

	rule1 = () => {
		let perceptionCenter = 150;
		let perceivedCenter = createVector(0, 0);

		let total = 0;
		for (let i = 0; i < boids.length; i++) {
			let distance = p5.Vector.dist(this.position, boids[i].position);
			if (boids[i] !== this) {
				if (distance < perceptionCenter) {
					perceivedCenter.add(boids[i].position);
					total++;
				}
			}
		}

		if (total > 0) {
			perceivedCenter.div(total);

			return p5.Vector.sub(perceivedCenter, this.position).div(100);
		}

		// perceivedCenter.div(boids.length - 1);

		// return p5.Vector.sub(perceivedCenter, this.position).div(100);
	};

	// rule1 = () => {
	// 	let centerOfMass = createVector(0, 0);
	// 	let perceivedCenter = createVector(0, 0);
	// 	let count = 0;

	// 	for (let i = 0; i < boids.length; i++) {
	// 		if (boids[i] != this) {
	// 			let distance = dist(
	// 				this.position.x,
	// 				this.position.y,
	// 				boids[i].position.x,
	// 				boids[i].position.y
	// 			);
	// 			if (distance < 200) {
	// 				// Only consider boids within 50 units
	// 				perceivedCenter.add(boids[i].position);
	// 				count++;
	// 			}
	// 		}
	// 	}
	// 	if (count > 0) {
	// 		perceivedCenter.div(count);
	// 		return p5.Vector.sub(perceivedCenter, this.position).div(100);
	// 	}
	// 	return createVector(0, 0);
	// };

	// rule2 = () => {
	// 	let c = createVector(0, 0);
	// 	let maxSeparationForce = 0.5;
	// 	for (let i = 0; i < boids.length; i++) {
	// 		if (boids[i] !== this) {
	// 			let distance = dist(
	// 				this.position.x,
	// 				this.position.y,
	// 				boids[i].position.x,
	// 				boids[i].position.y
	// 			);
	// 			if (distance < 50 && distance > 0) {
	// 				let diff = p5.Vector.sub(this.position, boids[i].position);
	// 				diff.div(distance); // Scale by inverse distance
	// 				c.add(diff);
	// 			}
	// 		}
	// 	}
	// 	c.limit(maxSeparationForce); // Cap the repulsion force
	// 	return c;
	// };

	rule2 = () => {
		let seperationDistance = 20;
		let c = createVector(0, 0);

		let total = 0;
		for (let i = 0; i < boids.length; i++) {
			if (boids[i] !== this) {
				let distance = p5.Vector.dist(this.position, boids[i].position);
				if (distance < seperationDistance) {
					let diff = p5.Vector.sub(this.position, boids[i].position);
					diff.div(distance ** 2);
					c.add(diff);
					total++;
				}
			}
		}

		if (total > 0) {
			return c.div(total);
		}
	};

	rule3 = () => {
		let perceptionCenter = 10;
		let perceivedVelocity = createVector(0, 0);
		let total = 0;
		for (let i = 0; i < boids.length; i++) {
			let distance = p5.Vector.dist(this.position, boids[i].position);
			if (boids[i] !== this) {
				if (distance < perceptionCenter) {
					// Only consider nearby boids
					perceivedVelocity.add(boids[i].velocity);
					total++;
				}
			}
		}

		if (total > 0) {
			perceivedVelocity.div(total);

			return p5.Vector.sub(perceivedVelocity, this.velocity).div(8);
		}
	};

	// rule3 = () => {
	// 	let perceivedVelocity = createVector(0, 0);
	// 	let count = 0;
	// 	for (let i = 0; i < boids.length; i++) {
	// 		if (boids[i] !== this) {
	// 			let distance = dist(
	// 				this.position.x,
	// 				this.position.y,
	// 				boids[i].position.x,
	// 				boids[i].position.y
	// 			);
	// 			if (distance < 50) {
	// 				// Only consider nearby boids
	// 				perceivedVelocity.add(boids[i].velocity);
	// 				count++;
	// 			}
	// 		}
	// 	}
	// 	if (count > 0) {
	// 		perceivedVelocity.div(count);
	// 		return p5.Vector.sub(perceivedVelocity, this.velocity).div(8);
	// 	}
	// 	return createVector(0, 0);
	// };

	update = () => {
		// this.x += Math.random() * 5 - 1;
		// this.y += Math.random() * 5 - 1;

		// Set vector by following the three rules
		this.vector1 = this.rule1(); // Cohesion (scale up)
		this.vector2 = this.rule2(); // Separation (default weight)
		this.vector3 = this.rule3(); // Alignment (default weight)

		// Set the velocity of the boid to the sum of the three rules
		this.velocity.add(this.vector1);
		this.velocity.add(this.vector2);
		this.velocity.add(this.vector3);

		let maxSpeed = 5;
		// Limit the velocity of the boid
		this.velocity.limit(maxSpeed);

		// Add velocity to position
		this.position.add(this.velocity);
	};

	boundPosition = () => {
		if (this.position.x < this.offsetBorder) {
			this.position.x = this.offsetBorder;
			this.velocity.x *= -1;
		} else if (this.position.x > width - this.offsetBorder) {
			this.position.x = width - this.offsetBorder;
			this.velocity.x *= -1;
		}

		if (this.position.y < this.offsetBorder) {
			this.position.y = this.offsetBorder;
			this.velocity.y *= -1;
		} else if (this.position.y > height - this.offsetBorder) {
			this.position.y = height - this.offsetBorder;
			this.velocity.y *= -1;
		}
	};
	show = () => {
		fill(255);
		stroke(255);
		rect(this.position.x, this.position.y, this.boidSize, this.boidSize);
	};
}
