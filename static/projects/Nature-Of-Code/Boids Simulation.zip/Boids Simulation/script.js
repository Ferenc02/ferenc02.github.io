/* Visual representation of one-dimensional Perlin noise */

let canvasWidth = 600;
let canvasHeight = 600;

let boids = [];

let amountOfBoids = 500;

function setup() {
	let canvas = createCanvas(canvasWidth, canvasHeight);
	canvas.parent('canvas');

	for (let i = 0; i < amountOfBoids; i++) {
		boids[i] = new Boid();
	}
}

function draw() {
	background(50);
	fill(255);

	stroke(255);
	noFill();
	// beginShape();

	boids.forEach((boid) => {
		//Show boids
		boid.show();
		// Update position for boids
		boid.update();

		// Bound position for boids
		boid.boundPosition();
	});
}

// let sliderElement = document.querySelector("#slider");
// let sliderText = document.querySelector("#slider-value");

// sliderElement.addEventListener("input", () => {
//   incrementValue = parseFloat(sliderElement.value);
//   sliderText.textContent = incrementValue;
// });
